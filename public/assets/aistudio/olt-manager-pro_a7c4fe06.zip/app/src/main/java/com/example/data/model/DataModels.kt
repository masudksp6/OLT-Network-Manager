package com.example.data.model

enum class OnuStatus(val labelBn: String, val rawValue: String) {
    ONLINE("অনলাইন", "online"),
    WIRECUT("ওয়্যার কাট", "wirecut"),
    POWEROFF("পাওয়ার অফ", "poweroff");

    companion object {
        fun fromRaw(raw: String): OnuStatus {
            return entries.firstOrNull { it.rawValue.equals(raw, ignoreCase = true) } ?: ONLINE
        }
    }
}

enum class PonStatus(val labelBn: String, val rawValue: String) {
    OPTIMAL("সক্রিয় (Optimal)", "optimal"),
    DEGRADED("ত্রুটিযুক্ত (Degraded)", "degraded"),
    DOWN("ডাউন (Down)", "down");

    companion object {
        fun fromRaw(raw: String): PonStatus {
            return entries.firstOrNull { it.rawValue.equals(raw, ignoreCase = true) } ?: OPTIMAL
        }
    }
}

data class PonInterface(
    val id: String,
    val type: String = "EPON PX20++",
    val status: String, // "optimal", "down", "degraded"
    val txPower: String,
    val sfpTemp: String,
    val voltage: String,
    val laserBias: String,
    val connected: Int,
    val maxOnu: Int = 64,
    val online: Int,
    val powerOff: Int,
    val wiredCut: Int
)

data class OnuItem(
    val id: Int,
    val user: String,
    val status: String, // "online", "wirecut", "poweroff"
    val fdb: String = "99.8%",
    val ip: String,
    val uptime: String,
    val port: String,
    val sn: String,
    val rx: String,
    val tx: String,
    val distance: String
)

data class OltItem(
    val id: Long,
    val name: String,
    val ip: String,
    val location: String,
    val user: String = "admin",
    val snmpVersion: String = "v2c",
    val community: String = "public",
    val status: String = "online", // "online", "offline"
    val vendor: String = "vsol", // "vsol", "bdcom", "huawei", "generic"
    val snmpPort: Int = 161
)

data class TelemetryMetrics(
    val cpuPercent: Int,
    val ramPercent: Int,
    val tempCelsius: Int,
    val uptime: String = "1d 9h 21m 49s"
)

data class DashboardData(
    val deviceName: String = "কোনো OLT যুক্ত নেই",
    val ip: String = "0.0.0.0",
    val snmpPort: Int = 161,
    val uptime: String = "0d 0h 0m 0s",
    val status: String = "offline",
    val cpuPercent: Int = 0,
    val ramPercent: Int = 0,
    val tempCelsius: Int = 0,
    val totalSubscribers: Int = 0,
    val onlineSubscribers: Int = 0,
    val onlinePercent: Double = 0.0,
    val powerOffSubscribers: Int = 0,
    val powerOffPercent: Double = 0.0,
    val wiredCutSubscribers: Int = 0,
    val wiredCutPercent: Double = 0.0,
    val activePonCount: Int = 0,
    val totalPonCount: Int = 0,
    val ponStatusText: String = "অসংযুক্ত",
    val ponDescription: String = "কোনো OLT কানেক্ট করা হয়নি",
    val totalBars: Int = 8,
    val activeBars: Int = 0
)

data class NotificationItem(
    val id: String,
    val type: String, // "error", "info", "warning"
    val title: String,
    val message: String,
    val timeAgo: String,
    val isRead: Boolean = false
)
