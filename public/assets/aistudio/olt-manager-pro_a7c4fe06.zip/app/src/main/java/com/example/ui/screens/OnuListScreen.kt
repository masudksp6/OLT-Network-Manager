package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OnuItem
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel

@Composable
fun OnuListScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val onuList by viewModel.onuList.collectAsState()
    val selectedOlt by viewModel.selectedOlt.collectAsState()
    val isRefreshingLive by viewModel.isRefreshingLive.collectAsState()

    var selectedPort by remember { mutableStateOf("EPON0/1") }
    var selectedFilter by remember { mutableStateOf("all") }
    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }

    // নির্বাচিত পোর্টের ONU সমূহ ফিল্টার (স্ক্রিনশটে EPON0/1 এর জন্য ৫টি প্রদর্শিত)
    val portOnus = remember(onuList, selectedPort) {
        val list = onuList.filter { it.port.startsWith(selectedPort) }
        if (list.isEmpty()) onuList.take(5) else list
    }

    val totalCount = portOnus.size
    val onlineCount = portOnus.count { it.status == "online" }
    val wireCutCount = portOnus.count { it.status == "wirecut" }
    val powerOffCount = portOnus.count { it.status == "poweroff" }

    val filteredList = remember(portOnus, selectedFilter, searchQuery) {
        portOnus.filter { onu ->
            val matchesFilter = when (selectedFilter) {
                "online" -> onu.status == "online"
                "wirecut" -> onu.status == "wirecut"
                "poweroff" -> onu.status == "poweroff"
                else -> true
            }
            val matchesQuery = searchQuery.isBlank() ||
                    onu.user.contains(searchQuery, ignoreCase = true) ||
                    onu.sn.contains(searchQuery, ignoreCase = true) ||
                    onu.ip.contains(searchQuery, ignoreCase = true)
            matchesFilter && matchesQuery
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("onu_list_screen")
    ) {
        // --- ১. হেডার রো (স্ক্রিনশটের অনুরূপ) ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "ONU তালিকা: $selectedPort",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 22.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(2.dp))
                val oltName = selectedOlt?.name ?: "V.SOL V1600D4-DP"
                Text(
                    text = "$oltName | $totalCount ONUs",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF64748B)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // লাইভ রিফ্রেশ বাটন
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE0F2FE))
                        .clickable { viewModel.refreshActiveOltData() }
                        .testTag("onu_refresh_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    if (isRefreshingLive) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = Color(0xFF0284C7)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh from OLT",
                            tint = Color(0xFF0284C7),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // সার্চ বাটন
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF1F5F9))
                        .clickable { isSearchActive = !isSearchActive }
                        .testTag("onu_search_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search ONU",
                        tint = Color(0xFF475569),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // সার্চ বার উন্মুক্ত থাকলে প্রদর্শন
        if (isSearchActive) {
            Spacer(modifier = Modifier.height(10.dp))
            GlobalSearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "SN, IP বা ক্লায়েন্টের নাম দিয়ে খুঁজুন...",
                testTag = "onu_search_input"
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- ২. পোর্ট সিলেক্টর ট্যাব রো (✓ EPON0/1, EPON0/2, EPON0/3) ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            listOf("EPON0/1", "EPON0/2", "EPON0/3").forEach { port ->
                val isSelected = selectedPort == port
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { selectedPort = port },
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) Color(0xFF16A34A) else Color.White,
                    border = if (isSelected) null else BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                        }
                        Text(
                            text = port,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else Color(0xFF1E293B)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- ৩. ৪টি সামারি কাউন্টার কার্ড রো (মোট, অনলাইন, ওয়্যার কাট, পাওয়ার অফ) ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GlobalStatCounterCard(
                count = "$totalCount",
                label = "মোট",
                containerColor = Color.White,
                textColor = Color(0xFF0F172A),
                modifier = Modifier.weight(1f)
            )

            GlobalStatCounterCard(
                count = "$onlineCount",
                label = "অনলাইন",
                containerColor = Color(0xFFDCFCE7),
                textColor = Color(0xFF15803D),
                modifier = Modifier.weight(1f)
            )

            GlobalStatCounterCard(
                count = "$wireCutCount",
                label = "ওয়ার কাট",
                containerColor = Color(0xFFFEE2E2),
                textColor = Color(0xFFDC2626),
                modifier = Modifier.weight(1f)
            )

            GlobalStatCounterCard(
                count = "$powerOffCount",
                label = "পাওয়ার অফ",
                containerColor = Color(0xFFFEF3C7),
                textColor = Color(0xFFD97706),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- ৪. ফিল্টার পিলস (সব, অনলাইন, ওয়্যার কাট, পাওয়ার অফ) ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OnuFilterPill(
                label = "সব ($totalCount)",
                isSelected = selectedFilter == "all",
                onClick = { selectedFilter = "all" }
            )

            OnuFilterPill(
                label = "অনলাইন ($onlineCount)",
                isSelected = selectedFilter == "online",
                onClick = { selectedFilter = "online" }
            )

            OnuFilterPill(
                label = "ওয়ার কাট ($wireCutCount)",
                isSelected = selectedFilter == "wirecut",
                onClick = { selectedFilter = "wirecut" }
            )

            OnuFilterPill(
                label = "পাওয়ার অফ ($powerOffCount)",
                isSelected = selectedFilter == "poweroff",
                onClick = { selectedFilter = "poweroff" }
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- ৫. ONU ক্লায়েন্ট কার্ড তালিকা ---
        if (filteredList.isEmpty()) {
            GlobalEmptyState(
                icon = Icons.Default.Person,
                title = "কোনো ONU পাওয়া যায়নি",
                subtitle = "অন্য পোর্ট বা ফিল্টার নির্বাচন করুন"
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredList, key = { it.id }) { onu ->
                    OnuClientCard(
                        onu = onu,
                        onCopySn = { sn ->
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("ONU SN", sn)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "SN কপি করা হয়েছে: $sn", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
fun OnuFilterPill(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(50),
        color = if (isSelected) Color(0xFF15803D) else Color.White,
        border = if (isSelected) null else BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else Color(0xFF1E293B),
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
        )
    }
}

@Composable
fun OnuClientCard(
    onu: OnuItem,
    onCopySn: (String) -> Unit
) {
    val isOnline = onu.status.equals("online", ignoreCase = true)
    val isWireCut = onu.status.equals("wirecut", ignoreCase = true)

    val statusText = when {
        isOnline -> "✓ অনলাইন"
        isWireCut -> "✗ ওয়্যার কাট"
        else -> "⚠ পাওয়ার অফ"
    }

    val statusColor = when {
        isOnline -> Color(0xFF16A34A)
        isWireCut -> Color(0xFFDC2626)
        else -> Color(0xFFD97706)
    }

    val iconColor = if (isOnline) Color(0xFF16A34A) else Color(0xFF94A3B8)

    GlobalCard(
        cornerRadius = 16.dp,
        elevation = 1.dp,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        testTag = "onu_client_${onu.id}"
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // শীর্ষ রো: ইউজার আইকন + নাম, স্ট্যাটাস
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "User",
                        tint = iconColor,
                        modifier = Modifier.size(20.dp)
                    )

                    Text(
                        text = onu.user,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = Color(0xFF0F172A)
                    )
                }

                Text(
                    text = statusText,
                    color = statusColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // দ্বিতীয় রো: OLT Switch FDB পিল এবং IP ও Uptime
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFEFF6FF)
                ) {
                    Text(
                        text = "OLT Switch FDB ${onu.fdb}",
                        color = Color(0xFF2563EB),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }

                Text(
                    text = "IP: ${onu.ip} • Up: ${onu.uptime}",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // তৃতীয় রো: ইনডেক্স, পোর্ট এবং SN (কপি আইকন সহ)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "#${onu.id}",
                    color = Color(0xFF2563EB),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = " ${onu.port} • SN: ${onu.sn}",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Medium
                )

                IconButton(
                    onClick = { onCopySn(onu.sn) },
                    modifier = Modifier.size(20.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy SN",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // চতুর্থ রো: সিগন্যাল ও টেলিমেট্রি বক্স
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFFF8FAFC),
                border = BorderStroke(1.dp, Color(0xFFF1F5F9))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp, horizontal = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Rx সিগন্যাল
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Rx সিগন্যাল", fontSize = 10.sp, color = Color(0xFF64748B))
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = onu.rx,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isOnline) Color(0xFF16A34A) else Color(0xFFDC2626)
                        )
                    }

                    // Tx পাওয়ার
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Tx পাওয়ার", fontSize = 10.sp, color = Color(0xFF64748B))
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = onu.tx,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                    }

                    // দূরত্ব
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("দূরত্ব", fontSize = 10.sp, color = Color(0xFF64748B))
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = onu.distance,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0284C7)
                        )
                    }
                }
            }
        }
    }
}
