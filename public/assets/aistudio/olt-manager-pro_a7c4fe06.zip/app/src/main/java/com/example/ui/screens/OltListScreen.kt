package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OltItem
import com.example.network.snmp.SnmpTestResult
import com.example.ui.components.*
import com.example.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@Composable
fun OltListScreen(viewModel: MainViewModel) {
    val oltList by viewModel.oltList.collectAsState()
    val selectedOlt by viewModel.selectedOlt.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingOlt by remember { mutableStateOf<OltItem?>(null) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var deleteTargetOlt by remember { mutableStateOf<OltItem?>(null) }

    val filteredList = remember(oltList, searchQuery) {
        if (searchQuery.isBlank()) {
            oltList
        } else {
            oltList.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                        it.ip.contains(searchQuery, ignoreCase = true) ||
                        it.location.contains(searchQuery, ignoreCase = true) ||
                        it.vendor.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("olt_list_screen")
    ) {
        // --- ১. হেডার রো ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "OLT ম্যানেজমেন্ট",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 22.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "মোট ডিভাইস: ${oltList.size}টি (V-SOL, BDCOM)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF64748B)
                )
            }

            // নতুন OLT যুক্ত করার জন্য প্লাস বাটন
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF0284C7))
                    .clickable {
                        editingOlt = null
                        showAddEditDialog = true
                    }
                    .testTag("add_olt_fab"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add OLT",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- ২. সার্চ বার ---
        GlobalSearchBar(
            query = searchQuery,
            onQueryChange = { searchQuery = it },
            placeholder = "OLT নাম, মডেল বা আইপি দিয়ে খুঁজুন...",
            testTag = "olt_search_bar"
        )

        Spacer(modifier = Modifier.height(14.dp))

        // --- ৩. OLT ডিভাইস তালিকা ---
        if (filteredList.isEmpty()) {
            GlobalEmptyState(
                icon = Icons.Default.Dns,
                title = "কোনো OLT ডিভাইস পাওয়া যায়নি",
                subtitle = "নতুন OLT যুক্ত করতে উপরের + বাটনে চাপুন"
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(filteredList, key = { it.id }) { olt ->
                    val isSelected = selectedOlt?.id == olt.id
                    OltDeviceCard(
                        olt = olt,
                        isSelected = isSelected,
                        onSelect = { viewModel.selectOlt(olt) },
                        onEdit = {
                            editingOlt = olt
                            showAddEditDialog = true
                        },
                        onDelete = {
                            deleteTargetOlt = olt
                            showDeleteConfirmDialog = true
                        },
                        onTestConnection = { ip, port, community ->
                            viewModel.testOlt(ip, port, community)
                        }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }

    // --- অ্যাড / এডিট ডায়ালগ ---
    if (showAddEditDialog) {
        OltAddEditModal(
            existingOlt = editingOlt,
            onDismiss = { showAddEditDialog = false },
            onSave = { olt ->
                if (editingOlt == null) {
                    viewModel.addOlt(olt)
                } else {
                    viewModel.updateOlt(olt)
                }
                showAddEditDialog = false
            },
            onTestConnection = { ip, port, community ->
                viewModel.testOlt(ip, port, community)
            }
        )
    }

    // --- ডিলিট নিশ্চিতকরণ ডায়ালগ ---
    if (showDeleteConfirmDialog && deleteTargetOlt != null) {
        GlobalDialog(
            title = "OLT ডিভাইস ডিলিট করবেন?",
            confirmButtonText = "হ্যাঁ, ডিলিট করুন",
            confirmButtonColor = Color(0xFFDC2626),
            onConfirm = {
                viewModel.deleteOlt(deleteTargetOlt!!.id)
                showDeleteConfirmDialog = false
                deleteTargetOlt = null
            },
            onDismissRequest = {
                showDeleteConfirmDialog = false
                deleteTargetOlt = null
            }
        ) {
            Text(
                text = "'${deleteTargetOlt!!.name}' ডিভাইসটি তালিকা থেকে মুছে ফেলতে চান? এটি ডিলিট করলে সকল কনফিগারেশন মুছে যাবে।",
                fontSize = 13.sp,
                color = Color(0xFF475569)
            )
        }
    }
}

@Composable
fun OltDeviceCard(
    olt: OltItem,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onTestConnection: suspend (String, Int, String) -> SnmpTestResult
) {
    val coroutineScope = rememberCoroutineScope()
    var isTesting by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<SnmpTestResult?>(null) }

    val vendorColor = when (olt.vendor.lowercase()) {
        "vsol" -> Color(0xFF0284C7)
        "bdcom" -> Color(0xFF059669)
        else -> Color(0xFF64748B)
    }

    GlobalCard(
        cornerRadius = 16.dp,
        elevation = if (isSelected) 3.dp else 1.dp,
        border = BorderStroke(
            1.5.dp,
            if (isSelected) Color(0xFF0284C7) else Color(0xFFE2E8F0)
        ),
        testTag = "olt_card_${olt.id}"
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // শীর্ষ রো: নাম, ভেন্ডর ব্যাজ এবং সিলেক্টেড স্ট্যাটাস
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = olt.name,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp,
                            color = Color(0xFF0F172A)
                        )

                        // ভেন্ডর ব্যাজ
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = vendorColor.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = olt.vendor.uppercase(),
                                color = vendorColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "লোকেশন: ${olt.location}",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                }

                if (isSelected) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color(0xFFE0F2FE)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Active",
                                tint = Color(0xFF0284C7),
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "ড্যাশবোর্ডে সক্রিয়",
                                color = Color(0xFF0284C7),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // আইপি এবং SNMP কনফিগ বক্স
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFFF8FAFC),
                border = BorderStroke(1.dp, Color(0xFFF1F5F9))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "IP: ${olt.ip}:${olt.snmpPort}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = "User: ${olt.user}",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "SNMP ${olt.snmpVersion}",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = "Community: ${olt.community}",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }

            // টেস্ট রেজাল্ট প্রদর্শনী
            if (testResult != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    color = if (testResult!!.success) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                    border = BorderStroke(1.dp, if (testResult!!.success) Color(0xFFBBF7D0) else Color(0xFFFECACA))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = testResult!!.message,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (testResult!!.success) Color(0xFF15803D) else Color(0xFFDC2626)
                        )
                        if (testResult!!.sysDescr != null) {
                            Text(
                                text = "মডেল: ${testResult!!.sysDescr}",
                                fontSize = 11.sp,
                                color = Color(0xFF334155)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // অ্যাকশন বাটনস: টেস্ট কানেকশন, সিলেক্ট, এডিট, ডিলিট
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // কানেকশন টেস্ট বাটন
                OutlinedButton(
                    onClick = {
                        coroutineScope.launch {
                            isTesting = true
                            testResult = onTestConnection(olt.ip, olt.snmpPort, olt.community)
                            isTesting = false
                        }
                    },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    border = BorderStroke(1.dp, Color(0xFF0284C7)),
                    modifier = Modifier.height(34.dp)
                ) {
                    if (isTesting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            strokeWidth = 2.dp,
                            color = Color(0xFF0284C7)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.NetworkCheck,
                            contentDescription = null,
                            tint = Color(0xFF0284C7),
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isTesting) "টেস্ট হচ্ছে..." else "কানেকশন টেস্ট",
                        color = Color(0xFF0284C7),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!isSelected) {
                        Button(
                            onClick = onSelect,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text(
                                text = "সক্রিয় করুন",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = onEdit,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        border = BorderStroke(1.dp, Color(0xFF64748B)),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(13.dp)
                        )
                    }

                    OutlinedButton(
                        onClick = onDelete,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        border = BorderStroke(1.dp, Color(0xFFEF4444)),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = null,
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun OltAddEditModal(
    existingOlt: OltItem?,
    onDismiss: () -> Unit,
    onSave: (OltItem) -> Unit,
    onTestConnection: suspend (String, Int, String) -> SnmpTestResult
) {
    val coroutineScope = rememberCoroutineScope()
    var vendor by remember { mutableStateOf(existingOlt?.vendor ?: "vsol") }
    var name by remember { mutableStateOf(existingOlt?.name ?: if (vendor == "vsol") "V.SOL V1600D4-DP" else "BDCOM GP3600-08") }
    var ip by remember { mutableStateOf(existingOlt?.ip ?: "") }
    var snmpPortStr by remember { mutableStateOf(existingOlt?.snmpPort?.toString() ?: "161") }
    var location by remember { mutableStateOf(existingOlt?.location ?: "") }
    var snmpVersion by remember { mutableStateOf(existingOlt?.snmpVersion ?: "v2c") }
    var community by remember { mutableStateOf(existingOlt?.community ?: "public") }

    var isTesting by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<SnmpTestResult?>(null) }

    GlobalDialog(
        title = if (existingOlt == null) "নতুন OLT যুক্ত করুন" else "OLT এডিট করুন",
        confirmButtonText = "সংরক্ষণ করুন",
        confirmButtonColor = Color(0xFF0284C7),
        onConfirm = {
            if (name.isNotBlank() && ip.isNotBlank()) {
                val port = snmpPortStr.toIntOrNull() ?: 161
                val olt = OltItem(
                    id = existingOlt?.id ?: System.currentTimeMillis(),
                    name = name.trim(),
                    ip = ip.trim(),
                    location = if (location.isBlank()) "প্রধান হাব" else location.trim(),
                    user = "admin",
                    snmpVersion = snmpVersion.trim(),
                    community = community.trim(),
                    status = existingOlt?.status ?: "online",
                    vendor = vendor,
                    snmpPort = port
                )
                onSave(olt)
            }
        },
        onDismissRequest = onDismiss
    ) {
        // ভেন্ডর নির্বাচন চিপস
        Text(
            text = "OLT ব্র্যান্ড / ভেন্ডর",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF334155)
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val vendors = listOf("vsol" to "V-SOL OLT", "bdcom" to "BDCOM OLT", "generic" to "অন্যান্য")
            vendors.forEach { (vKey, vLabel) ->
                val isSel = vendor == vKey
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSel) Color(0xFF0284C7) else Color(0xFFF1F5F9),
                    border = BorderStroke(1.dp, if (isSel) Color(0xFF0284C7) else Color(0xFFCBD5E1)),
                    modifier = Modifier
                        .clickable {
                            vendor = vKey
                            if (existingOlt == null) {
                                name = when (vKey) {
                                    "vsol" -> "V.SOL V1600D4-DP"
                                    "bdcom" -> "BDCOM GP3600-08"
                                    else -> "Generic OLT"
                                }
                            }
                        }
                ) {
                    Text(
                        text = vLabel,
                        color = if (isSel) Color.White else Color(0xFF334155),
                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        GlobalInput(
            value = name,
            onValueChange = { name = it },
            label = "OLT মডেল / নাম",
            placeholder = "উদা: V.SOL V1600D4-DP"
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(modifier = Modifier.weight(2.2f)) {
                GlobalInput(
                    value = ip,
                    onValueChange = { ip = it },
                    label = "Management IP ঠিকানা",
                    placeholder = "উদা: 192.168.1.100"
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                GlobalInput(
                    value = snmpPortStr,
                    onValueChange = { snmpPortStr = it },
                    label = "SNMP পোর্ট",
                    placeholder = "161"
                )
            }
        }
        GlobalInput(
            value = community,
            onValueChange = { community = it },
            label = "SNMP Community String",
            placeholder = "public"
        )
        GlobalInput(
            value = location,
            onValueChange = { location = it },
            label = "লোকেশন / ব্রাঞ্চ",
            placeholder = "উদা: মিরপুর ব্রাঞ্চ, ঢাকা"
        )

        // সরাসরি লাইভ কানেকশন টেস্ট বাটন
        OutlinedButton(
            onClick = {
                if (ip.isNotBlank()) {
                    coroutineScope.launch {
                        isTesting = true
                        val port = snmpPortStr.toIntOrNull() ?: 161
                        testResult = onTestConnection(ip.trim(), port, community.trim())
                        isTesting = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, Color(0xFF0284C7))
        ) {
            if (isTesting) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    strokeWidth = 2.dp,
                    color = Color(0xFF0284C7)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("সরাসরি OLT-তে পিং/SNMP টেস্ট হচ্ছে...", color = Color(0xFF0284C7), fontSize = 12.sp)
            } else {
                Icon(
                    imageVector = Icons.Default.NetworkCheck,
                    contentDescription = null,
                    tint = Color(0xFF0284C7),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("সরাসরি OLT কানেকশন টেস্ট করুন (UDP 161)", color = Color(0xFF0284C7), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        if (testResult != null) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = if (testResult!!.success) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                border = BorderStroke(1.dp, if (testResult!!.success) Color(0xFFBBF7D0) else Color(0xFFFECACA))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = testResult!!.message,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (testResult!!.success) Color(0xFF15803D) else Color(0xFFDC2626)
                    )
                    if (testResult!!.sysDescr != null) {
                        Text(
                            text = "রেসপন্স: ${testResult!!.sysDescr}",
                            fontSize = 11.sp,
                            color = Color(0xFF334155)
                        )
                    }
                }
            }
        }
    }
}
